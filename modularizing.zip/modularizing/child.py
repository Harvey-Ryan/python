import parent

print(locals())
# {'__name__': '__main__', '__doc__': None, '__package__': None, '__loader__': <_frozen_importlib_external.SourceFileLoader object at 0x000001DFDEC45890>, '__spec__': None, '__annotations__': {}, '__builtins__': <module 'builtins' (built-in)>, '__file__': 'C:\\Users\\harve\\Desktop\\python\\modularizing\\child.py', '__cached__': None, 'parent': <module 'parent' from 'C:\\Users\\harve\\Desktop\\python\\modularizing\\parent.py'>}

print(__name__)